# SmsSpamClassifier
In this project we have successfully filtered out spam and ham. We got 98% accuracy as well. This is the basic project in order to start learning NLP. 

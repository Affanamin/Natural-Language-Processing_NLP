# NLP-TextClassifier
Classified text through naive Bayes Classifier

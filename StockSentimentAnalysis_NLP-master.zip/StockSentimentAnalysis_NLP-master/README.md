# StockSentimentAnalysis_NLP
Predicting Stock movement based on headlines. A fun to learn NLP.

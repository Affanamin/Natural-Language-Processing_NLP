# DisasterTweets_orNot
Through this project we will predict whether a given tweet is about a real disaster or not. 

# Content-based-recomended-system.
In this project we have recommended movies through content of the movie. This is done through NLP. We have recommended most fitted 5 movies having same plot. In the end of this project there is a task for begineers as well. So complete the task and show it in comments. 
